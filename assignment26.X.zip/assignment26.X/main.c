//header files of respective files
#include <xc.h>
#include"ssd.h"
#include"main.h"
#include"digital_keypad.h"


#pragma config WDTE = OFF          //WATCHDOG TIMER ENABLED

unsigned char eeprom_test(unsigned int count) 
{
    /* Store the count value in the internal EEPROM */
    /* In SSD, the MSB bit will be represented on the left-most side */
    eeprom_write(0x01, (count / 1000)); /* Storing the thousands place at 0x01 */
    eeprom_write(0x02, (count / 100) % 10); /* Storing the hundreds place at 0x02 */
    eeprom_write(0x03, (count / 10) % 10); /* Storing the tens place at 0x03 */
    eeprom_write(0x04, (count % 10)); /* Storing the units place at 0x04 */
    eeprom_write(0x00, 1); /* Mark EEPROM as written */
}


static void init_config(void) 
{
    init_digital_keypad();
    init_ssd();
    
}

void main(void) 
{
    init_config();
    unsigned char ssd[MAX_SSD_CNT];
    unsigned int key, delay = 0, count = 0;
    unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    unsigned char pre_key = ALL_RELEASED;
    const unsigned int long_press = 200; // Threshold for long press
   
    
    
    /* Storing the value to start the counter when SW2 is pressed */
    if (eeprom_read(0x00) == 1) {
        count = eeprom_read(0x01) * 1000 + eeprom_read(0x02) * 100 + eeprom_read(0x03) * 10 + eeprom_read(0x04);
    } else {
        count = 0;
    }
    
    while(1)
    {
        key = read_digital_keypad(LEVEL);

        // Check for button press and release
        if (key == SW1 && pre_key == ALL_RELEASED)
        {
            delay = 1; // Start counting the delay on a new press
        }
        else if (key == ALL_RELEASED && pre_key == SW1)
        {
            if (delay < long_press)
            {
                // Short press detected, increment count
                count++;
            }
            delay = 0; // Reset delay after button release
        }
        else if (key == SW1)
        {
            delay++; // Button is still pressed, increment delay
            if (delay >= long_press)
            {
                // Long press detected, reset count
                count = 0;
                delay = 0; // Reset delay to avoid multiple resets
            }
        }

        // Update previous key state
        pre_key = key;

        // Reset count if it exceeds 9999
        if (count > 9999)
        {
            count = 0;
        }
        if(SW2 == key)
        {
            eeprom_test(count);  
        }
        // Update SSD display with the current count value
        ssd[3] = digit[count % 10];
        ssd[2] = digit[(count / 10) % 10];
        ssd[1] = digit[(count / 100) % 10];
        ssd[0] = digit[count / 1000];
        display(ssd);
    }
    // No return statement needed
}
 