#include <xc.h>
#include "main.h"
#include "ssd.h"
#include "adc.h"

#pragma config WDTE = OFF          // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) 
{
    init_ssd();
    init_adc();
}

void main(void) 
{
    unsigned long int count = 9999;
    unsigned long int delay = 1023;
    unsigned short adc_reg_val;
    unsigned char ssd[MAX_SSD_CNT];
    unsigned long int variable;
    init_config();
    unsigned char digit[]={ZERO,ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE};
    while (1)
    {
        // Read the ADC value
        adc_reg_val = read_adc();
       
        variable=((unsigned short) (adc_reg_val/102.3)*5);
        // Implement the delay based on ADC value
       if (delay++ >= (50-variable))
        {
            count--;
            delay = 0;
        }

        // Split count into digits for SSD display
        ssd[3] = digit[count % 10];
        ssd[2] = digit[(count / 10) % 10];
        ssd[1] = digit[(count / 100) % 10];
        ssd[0] = digit[(count / 1000) % 10];
        
        // Display the digits on the SSD
        display(ssd);
    }

    return;
}
