/* 
 * File:   adc.h
 */

#ifndef ADC_H
#define	ADC_H

void init_adc(void);
unsigned short read_adc(void);

#define CHANNEL0  0X00;

#endif	/* ADC_H */

