#include <xc.h>
#include "digital_keypad.h"


#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)

static void init_config(void) {
    TRISD = 0;
    PORTD = 0;
    init_digital_keypad();
}

void main(void) {
    
    
    
    unsigned char key;
    static unsigned long int period = 100, duty_cycle = 50,loop_counter = 0, wait = 0;
    init_config();
    while (1) 
    {
        
        key = read_digital_keypad(LEVEL);
        
        if (wait-- == 0)
        {

            wait = 1000;

            if (key == SW1)
            {
                if(duty_cycle != period)
                {
                  duty_cycle++;
                }
            }
            else if(key == SW2)
            {
                if (duty_cycle != 0)
                {
                    duty_cycle--;
                }
            }
        }
        if (loop_counter < duty_cycle)
        {
            RD0 = 1;
        }
        else if (loop_counter > duty_cycle)
        {
            RD0 = 0;
        }
        if(loop_counter++ == period)
        {
            loop_counter = 0;
        }
    }

}
