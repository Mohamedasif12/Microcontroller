/*
 * File:   main.c
 * Author: Asif
 *
 * Created on 21 May, 2024, 10:23 AM
 */


#include <xc.h>
#include"adc.h"
#pragma config WDTE = OFF          //WATCHDOG TIMER ENABLED

#define LED RD0


#define PERIOD 100 // Define the period for the PWM
static int duty_cycle;
void software_pwm()
{
    static unsigned int counter = 0;
    // Turn LED on or off based on the duty cycle
    if(counter < duty_cycle)
    {
        LED = 1; // LED on
    }
    else if(counter < PERIOD)
    {
        LED = 0; // LED off
    }

    // Increment counter and reset if it reaches the period
    counter++;
    if(counter >= PERIOD)
    {
        counter = 0;
    }
    }




static void init_config(void)
{
init_adc();
PORTD=0X00;
TRISD=0X00;
}

void main(void) 
{
    init_config();
    unsigned short adc_reg_val; // ADC value range: 0 to 1023 
    

    while(1)
    {
        adc_reg_val = read_adc(); // Read ADC value

        // Calculate duty cycle as a percentage of the ADC value
 duty_cycle = (unsigned int)((adc_reg_val / 1023.0) * PERIOD);

        // Control LED based on duty cycle
       software_pwm();
    }
    return;
}
