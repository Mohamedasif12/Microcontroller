/* 
 * File:   maim.h
 * Author: Asif
 *
 * Created on 30 April, 2024, 2:33 PM
 */

#ifndef MAIM_H
#define	MAIM_H


#define PRESSED 0
#define       LED_ARRAY1          TRISD 
#define       LED_ARRAY1_DDR      PORTD 
#endif





