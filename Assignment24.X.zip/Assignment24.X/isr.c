#include"timer.h"
#include<xc.h>
#include"main.h"

unsigned short blink;

void __interrupt()isr()
{
    static unsigned short count;
    
    if(TMR0IF == 1)
    {
        TMR0=TMR0+8; //6+2 Instruction cycle
        if(count++ == 10000)
        {
            blink++;
            count=0;
        }
      
    }
    TMR0IF=0;
}