/* 
 * File:   main.h
 * Author: Asif
 *
 * Created on 24 April, 2024, 6:34 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define  LEDD  PORTD
#define  TLED  TRISD


#define PRESSED 1

#endif