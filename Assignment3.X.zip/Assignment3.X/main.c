/*
 * File:   main.c
 * Author: Asif
 *
 * Created on 24 April, 2024, 6:35 PM
 */


#include <xc.h>
#include "main.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF          //WATCHDOG TIMER ENABLED

static void init_config(void) 
{
    //Makes as a output
    TRISD = 0x00;
    
    //PORTD led as off
    PORTD = 0x00;
    

    /* Initializing digital keypad */
    init_digital_keypad();
}

void main(void)
{    
    unsigned int long delay=0,pre_key;
    unsigned char key;
    init_config();
    
    while(1)
    {
        //read key value based on key press
        key=read_digital_keypad(LEVEL);
        
        if(key != ALL_RELEASED)
        {
            pre_key=key;
        }
        pressed_key(pre_key);               
    }
    return;
}
//based on the type we are blinking leds
void pressed_key(unsigned char key)
{
    static unsigned int wait=0;
    unsigned char static flag = 0;
    wait++;
    //this for loops
    static unsigned int i=0;
    static unsigned int j=0;
    if(key == SW1)
    {
         //Copy assignment1
        //create a delay
        if(wait == 20000)
        {
            wait=0;
            if(i < 8)
            {
                PORTD=(unsigned char) ((PORTD  << 1) | 0x01);
                i++;
            }
            else if(i >= 8 && i < 16) // Second condition OFF led from top to bottom 
            {
               PORTD = (unsigned char) (PORTD << 1);
                i++;
            }
            else if( i >=16 && i < 24)
            {
                PORTD=(unsigned char) ((PORTD >> 1) | 0x80);
                i++;
            }
            else if(i >=24 && i < 32)
            {
                PORTD=(unsigned char) (PORTD >> 1);
                i++;
            }
            if(i==32)
            {
                i=0;
            }
        }
    }
    else if(key == SW2)
    {
        //Code for pattern2
        //The LEDs should glow from left to Right and switch off from left to right, no direction control/ direction change
        if(wait == 20000 )
        {
            wait = 0;
            if(j < 8)
            {
                PORTD = (unsigned char) ((PORTD << 1) | 0x01) ;
                j++;
            } 
            else if(j >= 8 && j < 16) // Second condition OFF led from top to bottom 
            {
               PORTD = (unsigned char) (PORTD << 1);
                j++;
            }
            if(j == 16)  // for continuous process 
            {
               j = 0;
            } 
        }
    }
    else if(key == SW3)
    {
        //Code for pattern3
        //The LEDs should blink alternately
        if(wait == 20000)
        {
            wait = 0;
            flag=!flag;
            PORTD = 0xAA;  
        }
        if( flag)
        {
            PORTD = 0x55;
        }
}
    else if( key == SW4)
    {
        //Code for pattern4
        //The LEDs has to blink nibble wise, i.e first 4 LEDs will be ON, next 4 LEDs will be OFF, 
        //after first 4 LEDs will be OFF, next 4 LEDs will be ON.
        if( wait == 20000)
        {
            wait = 0;
            flag = !flag;
            PORTD = 0xF0;  
        }
        if( flag)
        {
            PORTD = 0x0F;
        }
    
    }
    
}