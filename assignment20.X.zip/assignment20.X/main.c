/*
 * File:   main.c
 */

#include <xc.h>
#include "clcd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    init_clcd();
}

void main(void) 
{
    init_config();
    char arr[]="Have a nice day!";
    char temp;
    unsigned long int delay = 5;
    while(1) 
    {
       
        clcd_print("Right Scrolling",LINE1(0));
        
        if(delay++ == 5)
        {
            delay=0;
        clcd_print(arr,LINE2(0));
        }
        temp=arr[15];
        
        for(int i=15;i>0;i--)
        {
            arr[i]=arr[i-1];
        }
        arr[0]=temp;
    }
    return;
}