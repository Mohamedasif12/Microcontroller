/*
 * File:   main.c
 * Author: Asif
 *
 * Created on 21 May, 2024, 9:55 PM
 */

#include <xc.h>
#include "clcd.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void)
{
    init_clcd();
    init_digital_keypad();
}

void delay(unsigned int ms)
{
    while(ms--)
    {
        __delay_ms(1);
    }
}

void main(void)
{
    init_config();
    unsigned char arr[] = "0000000000";
    unsigned char key;
    
    unsigned char flag = 1; // 1 for edit mode, 0 for run mode
    unsigned int index = 9;
    unsigned char blink = 0;

    while (1)
    {
        key = read_digital_keypad(STATE);
        clcd_print("DOWN_COUNTER",LINE1(0));
        clcd_print(arr, LINE2(6));
        clcd_print("Count:", LINE2(0));
        if (flag == 1) // Edit mode
        {
            // Blinking cursor logic
            if (blink)
            {
                clcd_putch(' ', LINE2(6 + index));
                clcd_print(arr,LINE2(6));
            }
            else
            {
                clcd_putch(arr[index], LINE2(6 + index));
            }
            blink = !blink;

            if (key == SW1)
            {
                if (arr[index] < '9')
                {
                    arr[index]++;
                }
                else
                {
                    arr[index] = '0'; // Wrap around to '0' after '9'
                }
            }
            else if (key == SW2 && index > 0)
            {
                index--;
            }
            else if (key == SW3)
            {
                flag = 0; // Switch to run mode
            }
        }
        else if (flag == 0) // Run mode
        {
            

            if (key == SW3)
            {
                flag = 1; // Switch back to edit mode
            }
            else
            {
                // Check if all digits are '0'
                int all_zero = 1;
                for (int i = 0; i < 10; i++)
                {
                    if (arr[i] != '0')
                    {
                        all_zero = 0;
                        break;
                    }
                }
                
                if (!all_zero)
                {
                    // Down counter logic
                    if (arr[9] > '0')
                    {
                        arr[9]--;
                    }
                    else
                    {
                        for (int i = 9; i > 0; i--)
                        {
                            if (arr[i] == '0')
                            {
                                arr[i] = '9';
                                if (arr[i-1] > '0')
                                {
                                    arr[i-1]--;
                                    break;
                                }
                            }
                            else
                            {
                                arr[i]--;
                                break;
                            }
                        }
                    }
                }
            }
        }
   
    }
    return;
}
