/* 
 * File:   main.h
 * Author: Asif
 *
 * Created on 2 May, 2024, 7:25 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define SSD_MAX 4


#endif	/* MAIN_H */

