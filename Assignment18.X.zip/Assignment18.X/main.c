#include <xc.h>
#include "clcd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    init_clcd();
}

void main(void) 
{
    init_config();
    char arr[] = "9999999999";
    unsigned long int delay = 0;
    unsigned char count = 10;
    while(1) 
    {
        // Print the line1 -> DOWN_COUNTER 
        clcd_print("DOWN_COUNTER", LINE1(0));
        
        // Print static message to indicate as count
        clcd_print("COUNT:", LINE2(0));
        
        // Printing the arr first index
        clcd_print(arr, LINE2(6));
        arr[9]--;
       
        //using for loop check the condition increment one by one 
        for(int i=9;i>0;i--)
        {
            //based on array[index] value incrementing the value
            if(arr[i] < '0')
            {
                arr[i-1]--;
                arr[i]='9';
            }
        }
    }
    return;
}