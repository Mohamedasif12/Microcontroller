#include <xc.h>
#include "ssd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    init_ssd(); // Initialize the seven-segment display
}

void main(void) {
    unsigned char ssd[MAX_SSD_CNT];
    unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE,UND,UND};
    unsigned int delay=100;
    unsigned int count=0;
    unsigned int i = 0;

    init_config(); // Initialize system configurations
    while(1)
    {
        if(!delay--)
        {
            delay=100;  
               i++;
        }
        if(i >= 12)
        {
            i=0;
        }
            ssd[0] = digit[i%12];         
            ssd[1] = digit[(i+1)%12];   
            ssd[2] = digit[(i+2)%12];  
            ssd[3] = digit[(i+3)%12];          
            display(ssd);
    }   
           
  
    return; // This statement will not be reached, included for completeness
}