/* 
 * File:   timer.h
 * Author: Asif
 *
 * Created on 17 May, 2024, 8:04 PM
 */

#ifndef TIMER_H
#define	TIMER_H

//FUNCTION PROTOTYPE
void init_timer0(void);
void init_timer1(void);
void init_timer2(void);

#endif	/* TIMER_H */

