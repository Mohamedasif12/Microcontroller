/*
 * File:   main.c
 * Author: Asif
 * Assignment:Implement the time separator with Timer 0, Timer 1 and Timer 2
 * Created on 17 May, 2024, 8:02 PM
 */


#include <xc.h>
#include"timer.h"
#include"main.h"
#pragma config WDTE = OFF          //WATCHDOG TIMER ENABLED

static void init_config(void)
{
    
    LED_PORTD_DDR = 0x00;   //To make the PORTD as an Output port.
    LED_ARRAY = 0x00;       //To turn OFF the LEDs when the Power is ON.
    
    init_timer0();
    TMR0IF = 0;			//To clear the Timer0 Overflow Interrupt Flag Bit.
    
    init_timer1();
    TMR1IF = 0;         //To clear the Timer2 Overflow Interrupt Flag Bit.}

    init_timer2();
	TMR2IF = 0;			//To clear the Timer2 Overflow Interrupt Flag Bit.
    
    GIE = 1;
    PEIE = 1;           //peripheral int enable bit 
    
    
}

void main(void) 
{
    init_config();
    
    while(1)
    {
        ;
    }
    return;
}
