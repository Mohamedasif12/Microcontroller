/* 
 * File:   main.h
 * Author: Mohamed Asif
 *
 * Created on 17 May, 2024, 8:02 PM
 */

#ifndef MAIN_H
#define	MAIN_H



/* Macro for the PORTS */
#define LED_PORTD_DDR TRISD
#define LED_ARRAY PORTD

#define LED0 RD0
#define LED1 RD1
#define LED2 RD2


#endif	/* MAIN_H */

