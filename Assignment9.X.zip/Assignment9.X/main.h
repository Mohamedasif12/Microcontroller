/* 
 * File:   main.h
 * Author: Asif
 *
 * Created on 17 May, 2024, 7:47 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#define MAX_SSD 4
void init_timer0(void);
#endif	/* MAIN_H */

