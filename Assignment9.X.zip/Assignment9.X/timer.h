/* 
 * File:   timer.h
 * Author: Asif
 *
 * Created on 17 May, 2024, 7:58 AM
 */

#ifndef TIMER_H
#define	TIMER_H

void init_timer0(void);
#endif	/* TIMER_H */

