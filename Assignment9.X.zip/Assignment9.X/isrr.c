/*
 * File:   isrr.c
 * Author: Asif
 *
 * Created on 17 May, 2024, 8:32 AM
 */


#include <avr/io.h>

int main(void) {
    /* Replace with your application code */
    while (1) {
    }
}
