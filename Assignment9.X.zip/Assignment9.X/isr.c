
#include<xc.h>
#include"main.h"
#include "ssd.h"

//extern unsigned char count;
unsigned char count = 0;

void __interrupt() isr(void) {
    static unsigned int timer = 0;
    //Timer Interrupt flag
    if (TMR0IF == 1) 
    {
        TMR0 = TMR0 + 8; 
        
        if (timer++ == 10000) 
        {
            timer = 0;
            count += 1; //Increment the 'count' by 1.
        }

        TMR0IF = 0; //To clear the Timer0 Overflow Interrupt Flag Bit to avoid Recursive interrupts.
    }
}


/*FORMULA
 we need find x
 * if(timer++ = x?)
 * find precise second
 * 1 ticks =total ticks * quantum * 10^-9 *scale
 * 1 Ticks = 256 * 200 * 1 * 10^-9
 * 1 ticks = 51.2 us
 * ------------------------------------------------------
 * x=count *51.2 us
 * x= 20000*51.2 us = 1.024 sec
 * --------------------------------------------------------
 * I need it for 0.5 sec
 * x=count *51.2 us
 * 51.2*10000= 0.512 sec
 * Precise i need 0.5 sec
 * change the ticks
 * I intialized TMR0=6; 6 ....... 256 - 250 resolutions
 * ---------------------------------------------------------
 * 1 ticks =total ticks * quantum * 10^-9 *scale
 * 1 Ticks = 250 * 200 * 1 * 10^-9
 * 1 ticks = 50.00 us
 * X=count *50.00
 * x=10000* 50.00
 * x=0.5 sec
 * x value = 10000
 * TMR = TMR + 6;
*/ 