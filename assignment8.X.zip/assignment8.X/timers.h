/* 
 * File:   timers.h
 * Author: Asif
 *
 * Created on 22 May, 2024, 10:11 PM
 */

#ifndef TIMERS_H
#define	TIMERS_H

unsigned int req_time;
void init_timer0(void);


#endif	/* TIMERS_H */

