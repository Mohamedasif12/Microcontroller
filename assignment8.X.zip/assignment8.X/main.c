/*
 * File:   main.c
 * Author: Asif
 *
 * Created on 22 May, 2024, 7:39 PM
 */


#include <xc.h>
#include"adc.h"

static unsigned int duty_cycle;
#pragma config WDTE = OFF          //WATCHDOG TIMER ENABLED

static void init_config(void) 
{
    init_adc();
    init_timer0();
    GIE=1;
    PEIE=1;
}

void main(void) 
{
    unsigned short adc_reg_val;
    init_config();
  
    while(1)
    {
    adc_reg_val=read_adc(CHANNEL0);
    
    duty_cycle=adc_reg_val / 10.23;
    
    software_pwm(duty_cycle);
    }
    return;
}
