/*
 * File:   main.c
 * Author: Asif
 *
 * Created on 2 May, 2024, 11:45 AM
 */


#include <xc.h>
#include"main.h"
#pragma config WDTE = OFF          //WATCHDOG TIMER ENABLED

static void init_config(void) 
{
 init_ssd();
}

void main(void) {
    init_config();
    unsigned char ssd[SSD_MAX];
    unsigned long int delay=100;
    unsigned int key;
    
    key=read_digital_keypad(LEVEL);
    
    if(key == SW1)
    {
        
    }
    
    return;
}
