/* 
 * File:   main.h
 * Author: Asif
 *
 * Created on 2 May, 2024, 11:48 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#define SSD_MAX 15

#endif	/* MAIN_H */

