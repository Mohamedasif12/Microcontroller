/* 
 * File:   digital_keypad.h
 * Author: Asif
 *
 * Created on 24 April, 2024, 6:54 PM
 */

#ifndef DIGITAL_KEYPAD_H
#define	DIGITAL_KEYPAD_H

//find the PULLUP OR PULLDOWN
#define LEVEL_DETECTION         0
#define LEVEL                   0


//FIND THE PULUP OR PULLDOWN
#define STATE_DETECTION         1
#define STATE                   1


//KEYPAD PORT CONFIGURATION
#define KEYPAD_PORT             PORTB
#define KEYPAD_PORT_DDR         TRISB


//If opened 0x3f 0011 1111
#define INPUT_LINES             0x3F       //except 0011 1111 released also same

#define SW1          0X3E 
#define SW2          0X3D
#define SW3          0X3B
#define SW4          0X37
#define SW5          0X2F
#define SW6          0X1F

#define ALL_RELEASED            INPUT_LINES

unsigned char read_digital_keypad(unsigned char mode);
void init_digital_keypad(void);
void pressed_key(unsigned char pre_key);

#endif	/* DIGITAL_KEYPAD_H */

